import asyncio
import logging
import os
import sys
import socket
from pathlib import Path
from cryptography.x509.oid import ExtendedKeyUsageOID
sys.path.insert(0, "..")
from asyncua import Client
from asyncua.crypto.security_policies import SecurityPolicyBasic256Sha256
from asyncua.crypto.cert_gen import setup_self_signed_certificate
from asyncua.crypto.validator import CertificateValidator, CertificateValidatorOptions
from asyncua.crypto.truststore import TrustStore
import warnings
import configparser

logging.disable(logging.CRITICAL) # Ocultar todos los mensajes de las librerias asyncua
USE_TRUST_STORE = True

cert_idx = 4

async def task(loop):
    host_name = socket.gethostname()
    print("--",host_name) # DSIP202KEPW.sercor.itp.es?
    client_app_uri = c_uri
    url = c_url

    await setup_self_signed_certificate(private_key,
                                        cert,
                                        client_app_uri,
                                        host_name,
                                        [ExtendedKeyUsageOID.CLIENT_AUTH],
                                        {
                                            'countryName': c_country_name,
                                            'stateOrProvinceName': c_state_name,
                                            'localityName': c_locality,
                                            'organizationName': c_organization,
                                        })
    client = Client(url=url)
    client.application_uri = client_app_uri
    await client.set_security(
        SecurityPolicyBasic256Sha256,
        certificate=str(cert),
        private_key=str(private_key),
        server_certificate= root_dir + "\\server_cert.der"
    )

    if USE_TRUST_STORE:
        trust_store = TrustStore([Path('examples') / 'certificates' / 'trusted' / 'certs'], [])
        await trust_store.load()
        validator =CertificateValidator(CertificateValidatorOptions.TRUSTED_VALIDATION|CertificateValidatorOptions.PEER_SERVER, trust_store)
    else:
        validator =CertificateValidator(CertificateValidatorOptions.EXT_VALIDATION|CertificateValidatorOptions.PEER_SERVER)
    client.certificate_validator = validator
    try:
        async with client:
            objects = client.nodes.objects
            child = await objects.get_child(['0:MyObject', '0:MyVariable'])
            await child.get_value()
            await child.set_value(42)
            await child.get_value()
    except Exception:
        pass


def main():
    loop = asyncio.get_event_loop()
    loop.set_debug(True)
    loop.run_until_complete(task(loop))
    loop.close()
    input("Clave y certificados generados")

if __name__ == "__main__":
    
    with warnings.catch_warnings(action="ignore"):
        if getattr(sys, 'frozen', False): # Si se está ejecutando como un ejecutable
            root_dir = os.path.dirname(sys.executable)
        else: # Si se está ejecutando como un script normal 
            root_dir = os.path.dirname(os.path.abspath(__file__))
        cert = Path(root_dir + "\\client_cert.der")
        private_key = Path(root_dir + "\\client_key.pem")

        config = configparser.ConfigParser()
        config.read(root_dir + '\\config.ini')
        c_url = config['OPCConfig']['url']
        c_uri = config['OPCConfig']['uri']
        c_country_name = config['OPCConfig']['countryName']
        c_state_name = config['OPCConfig']['stateOrProvinceName']
        c_locality = config['OPCConfig']['localityName']
        c_organization = config['OPCConfig']['organizationName']

        main()
