El .exe genera un certificado y una clave para poder utilizar para clientes OPC-UA.
Se ha testado correctamente para el servidor de Kepware con SignAndEncrypt Basic256Sha256.
El código fuente es una modificación del proporcionado en la pagina oficial de GitHub:
https://github.com/FreeOpcUa/opcua-asyncio

Seguir los siguientes pasos:

1. Extraer el certificado del servidor y colocarlo en la carpeta con el nombre de 'server_cert.der'.
2. Modificar 'config.ini' para ajustar los parámetros del certificado (usar la URL del servidor)
3. Ejecutar el .exe y utilizar los archivos generados 'client_key.pem' y 'client_cert.der'

(!)
El ejecutable también envía el certificado al servidor (se intenta conectar).
Si se acepta este certificado, debe usarse exactamente este mismo para el cliente junto a su clave.
Modificar el archivo para modificar el certificado hace necesario aceptar el nuevo certificado en el servidor.

(!)
El código fuente también se proporciona, pero es recomendable no modificarse ya que está estandarizado.
Además, es propenso a generar excepciones al modificarse.

(!)
Si 'config.ini' no existe o es correcto, o 'server_cert.der' no existe o no es correcto, no funcionara el ejecutable.
Mientras los tres archivos se encuentren en la misma carpeta, la ruta no importa.
Considerar que pueden darse problemas al crear los archivos si esto se bloquea debido a permisos de administrador.
